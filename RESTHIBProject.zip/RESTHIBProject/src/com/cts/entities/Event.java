package com.cts.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Event")
public class Event {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="Event_Id")
private int eventId;
@Column(name="Event_Name")
private String name;
@OneToOne
@JoinColumn(name="Location_Id")
private Location location;
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Location getLocation() {
	return location;
}
public void setLocation(Location location) {
	this.location = location;
}


}
