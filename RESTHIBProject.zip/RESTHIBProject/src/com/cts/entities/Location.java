package com.cts.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="Location")
@XmlRootElement
public class Location {
@Id
@Column(name="Location_Id")
private int locationId;
@Column(name="Name")
private String name;
public int getLocationId() {
	return locationId;
}
public void setLocationId(int locationId) {
	this.locationId = locationId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
